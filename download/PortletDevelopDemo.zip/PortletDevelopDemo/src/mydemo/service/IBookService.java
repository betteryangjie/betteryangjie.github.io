package mydemo.service;

import java.util.List;

import mydemo.bean.Book;
import mydemo.dao.IBookDao;


public interface IBookService {
	public void setBookDao(IBookDao bookDao);

	public IBookDao getBookDao();

	public List<Book> getBooks();
	
	public List<String> getIds();
	
	public Book getBookById(String id);
}
