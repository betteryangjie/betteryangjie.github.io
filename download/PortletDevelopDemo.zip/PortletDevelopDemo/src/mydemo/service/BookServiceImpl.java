package mydemo.service;

import java.util.List;

import mydemo.bean.Book;
import mydemo.dao.IBookDao;


public class BookServiceImpl implements IBookService {
	private IBookDao bookDao = null;

	public IBookDao getBookDao() {
		return bookDao;
	}

	public void setBookDao(IBookDao bookDao) {
		this.bookDao = bookDao;
	}

	public List<Book> getBooks() {
		return this.bookDao.getBooks();
	}
	
	public List<String> getIds(){
		return this.bookDao.getIds();
	}

	@Override
	public Book getBookById(String id) {
		return this.bookDao.getBookById(id);
	}
}
