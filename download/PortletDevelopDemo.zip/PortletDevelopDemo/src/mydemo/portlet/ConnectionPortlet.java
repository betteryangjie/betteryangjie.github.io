package mydemo.portlet;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletSession;

import org.apache.struts2.portlet.dispatcher.Jsr168Dispatcher;

public class ConnectionPortlet extends Jsr168Dispatcher {
	public void processAction(ActionRequest request, ActionResponse response)
			throws PortletException, IOException {
		String id = request.getParameter("id");
		PortletSession portletSession = request.getPortletSession();
		// ��Ӧ����������idֵ
		portletSession.setAttribute("id", id, PortletSession.APPLICATION_SCOPE);

		super.processAction(request, response);
	}
}
