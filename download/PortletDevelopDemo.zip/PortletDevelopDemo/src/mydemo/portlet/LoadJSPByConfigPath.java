package mydemo.portlet;

import java.io.IOException;
import java.net.URLEncoder;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

public class LoadJSPByConfigPath extends GenericPortlet {

	public static final String VIEW_JSP = "/jsp/LoadJSPByConfigPath/view/jspportlet_viewdefault.jsp";
	public static final String EDIT_JSP = "/jsp/LoadJSPByConfigPath/edit/jspportlet_edit.jsp";

	public LoadJSPByConfigPath() {
	}

	public void doView(RenderRequest request, RenderResponse response)
			throws PortletException, IOException {
		response.setContentType("text/html");
		PortletPreferences prefs = request.getPreferences();
		String jsp = request.getParameter("jsp");

		if (jsp == null) {
			jsp = prefs.getValue("jsp", VIEW_JSP);
			System.out.println("doView:prefs.getValue(\"jsp\", VIEW_JSP)="
					+ jsp);
		} else {
			System.out.println("doView:request.getParameter(\"jsp\")=" + jsp);
		}

		try {
			PortletRequestDispatcher rd = getPortletContext()
					.getRequestDispatcher(jsp);
			rd.include(request, response);
		} catch (Exception ex) {
			response.setProperty("expiration-cache", "0");
			PortletRequestDispatcher rd = getPortletContext()
					.getRequestDispatcher(jsp);
			rd.include(request, response);
		}
	}

	public void doEdit(RenderRequest request, RenderResponse response)
			throws PortletException, IOException {
		response.setContentType("text/html");
		PortletPreferences prefs = request.getPreferences();
		String jsp = prefs.getValue("jsp", VIEW_JSP);
		System.out.println("doEdit:input jsp location=" + jsp);
		request.setAttribute("jsp", jsp);
		String error = request.getParameter("error");
		request.setAttribute("error", error);
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(
				EDIT_JSP);
		rd.include(request, response);
	}

	public void processAction(ActionRequest request, ActionResponse response)
			throws PortletException, IOException {
		PortletPreferences prefs = request.getPreferences();
		if (request.getPortletMode().equals(PortletMode.VIEW)) {
			String jsp = request.getParameter("jsp");
			if (jsp == null) {
				jsp = prefs.getValue("jsp", VIEW_JSP);
				System.out
						.println("processAction:prefs.getValue(\"jsp\", VIEW_JSP)="
								+ jsp);
			} else {
				System.out
						.println("processAction:request.getParameter(\"jsp\")="
								+ jsp);
			}

			response.setRenderParameter("jsp", jsp);
		} else if (request.getPortletMode().equals(PortletMode.EDIT)) {
			String errorMsg = null;
			String jsp = request.getParameter("jsp");
			System.out.println("processAction:request.getParameter(\"jsp\")="
					+ jsp);
			prefs.setValue("jsp", jsp);
			boolean editOK;
			try {
				prefs.store();
				editOK = true;
			} catch (Exception ex) {
				editOK = false;
				errorMsg = ex.getMessage();
			}
			if (editOK) {
				response.setPortletMode(PortletMode.VIEW);
			} else {
				response.setRenderParameter("error", URLEncoder
						.encode(errorMsg));
			}
		}
	}
}
