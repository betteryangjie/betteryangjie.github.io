package mydemo.portlet;

import java.io.IOException;

import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

public class HelloWorld extends GenericPortlet {
	public static final String VIEW_JSP = "/jsp/helloworld/view/helloworld.jsp";

	protected void doView(RenderRequest request, RenderResponse response)
			throws PortletException, IOException {
		response.setContentType(request.getResponseContentType());
		PortletRequestDispatcher dispatcher = getPortletContext()
				.getRequestDispatcher(VIEW_JSP);
		dispatcher.include(request, response);
	}
}
