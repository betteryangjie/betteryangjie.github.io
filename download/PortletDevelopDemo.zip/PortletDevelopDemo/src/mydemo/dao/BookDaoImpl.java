package mydemo.dao;

import java.util.List;

import mydemo.bean.Book;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;


public class BookDaoImpl extends SqlMapClientDaoSupport implements IBookDao {

	public List<Book> getBooks() {
		return this.getSqlMapClientTemplate().queryForList("book.getBooks");
	}

	@Override
	public Book getBookById(String id) {
		Object obj = this.getSqlMapClientTemplate().queryForObject("book.getBookById",id);
		return obj==null?null:(Book)obj;
	}
	
	public List<String> getIds() {
		Object obj = this.getSqlMapClientTemplate().queryForList("book.getIds");
		return obj==null?null:(List<String>)obj;
	}
}
