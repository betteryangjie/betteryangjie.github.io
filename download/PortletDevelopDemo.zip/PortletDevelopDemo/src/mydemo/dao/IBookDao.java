package mydemo.dao;

import java.util.List;

import mydemo.bean.Book;


public interface IBookDao {
	public List<Book> getBooks();
	public List<String> getIds();
	public Book getBookById(String id);
}
