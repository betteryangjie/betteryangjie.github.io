package mydemo.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

public class ConnectionAction extends ActionSupport {
	protected final Log log = LogFactory.getLog(getClass());

	private String id = null;

	public String execute() throws Exception {
		if (log.isInfoEnabled()) {
			log.info("***************start detail books***************");
		}

		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		id = (String) session.getAttribute("id");

		if (log.isInfoEnabled()) {
			log.info("id: " + id);
			log.info("***************end detail books***************");
		}
		return SUCCESS;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
