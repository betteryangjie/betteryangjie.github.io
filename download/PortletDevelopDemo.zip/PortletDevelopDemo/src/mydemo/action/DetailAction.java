package mydemo.action;

import java.util.Map;

import javax.portlet.PortletPreferences;

import mydemo.bean.Book;
import mydemo.service.IBookService;

import org.apache.struts2.dispatcher.DefaultActionSupport;
import org.apache.struts2.interceptor.ParameterAware;
import org.apache.struts2.portlet.interceptor.PortletPreferencesAware;

import com.opensymphony.xwork2.Preparable;


public class DetailAction extends DefaultActionSupport implements Preparable, ParameterAware{
	private IBookService bookService = null;
	Book book = new Book();
	String id;
	private Map<String, String[]> parameters;

	public void setParameters(Map<String, String[]> parameters) {
		this.parameters = parameters;
	}
	
	public void prepare() throws Exception {
		// Since the prepare interceptor is run before the parameter interceptor, 
		// we have to get the parameter "manually".
		this.id = parameters.get("id")[0];
	}

	@Override
	public String execute() throws Exception {
		book = this.bookService.getBookById(id);
		return SUCCESS;
	}

	public IBookService getBookService() {
		return bookService;
	}

	public void setBookService(IBookService bookService) {
		this.bookService = bookService;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public String getId() {
		return id;
	}

}
