package mydemo.action;

import java.util.ArrayList;
import java.util.List;

import mydemo.bean.Book;
import mydemo.service.IBookService;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.opensymphony.xwork2.ActionSupport;


public class ViewAction extends ActionSupport {
	protected final Log log = LogFactory.getLog(getClass());
	private IBookService bookService = null;
	List<Book> books = new ArrayList<Book>();
	List<String> Ids = new ArrayList<String>();

	public String execute() throws Exception {
		if (log.isInfoEnabled()) {
			log.info("***************start view books***************");
		}

		books = this.bookService.getBooks();

		if (log.isInfoEnabled()) {
			log.info("books size: " + books.size());
			log.info("***************end view books***************");
		}

		return SUCCESS;
	}
	
	public String listIds() throws Exception {
		if (log.isInfoEnabled()) {
			log.info("***************start view books***************");
		}

		Ids = this.bookService.getIds();

		if (log.isInfoEnabled()) {
			log.info("books size: " + books.size());
			log.info("***************end view books***************");
		}

		return SUCCESS;
	}

	public IBookService getBookService() {
		return bookService;
	}

	public void setBookService(IBookService bookService) {
		this.bookService = bookService;
	}

	public List getBooks() {
		return books;
	}

	public void setBooks(List books) {
		this.books = books;
	}

	public void setIds(List<String> ids) {
		Ids = ids;
	}

	public List<String> getIds() {
		return Ids;
	}

}
